# Astroport xASTRO Token

This is the Astroport xASTRO token implementation.

---

## CW20 Based Token Contract

This is a basic implementation of a CW20 base contract which can be found [here](https://github.com/CosmWasm/cw-plus/tree/main/contracts/cw20-base). It implements the [CW20 spec](https://github.com/CosmWasm/cosmwasm-plus/tree/master/packages/cw20) and is designed to be imported into other contracts in order to easily build other CW20-compatible tokens with balance snapshotting logic.
