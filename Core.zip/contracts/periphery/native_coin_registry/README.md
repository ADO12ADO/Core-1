# Astroport native coins registry contract

The registry contract contains native assets with their precision. 